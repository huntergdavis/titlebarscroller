Thank you for Trying TitleScroller, a more enlightened way to waste your work time...umm I mean read books at home... Yeah.
Only TitleScroller allows you to read books on the current active window, saving you valuable desktop space.  

Howto:
Step 1. Select load file, and load your text file in.
Step 2. Press PLay.

That's it, all of the other controls work just like a regular jukebox.